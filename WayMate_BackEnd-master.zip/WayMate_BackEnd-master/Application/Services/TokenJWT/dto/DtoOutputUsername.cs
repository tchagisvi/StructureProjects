﻿namespace Application.Services.TokenJWT.dto; 

public class DtoOutputUsername {
    public string? username { get; set; }
}
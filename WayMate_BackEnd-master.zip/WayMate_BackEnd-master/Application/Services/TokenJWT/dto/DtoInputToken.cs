﻿using Domain.Enums;

namespace Application.Services.TokenJWT.dto; 

public class DtoInputToken {
    public string username { get; set; }
    public string userType { get; set; }
}

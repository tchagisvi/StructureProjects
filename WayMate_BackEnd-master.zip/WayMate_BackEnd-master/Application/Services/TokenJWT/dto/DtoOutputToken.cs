﻿namespace Application.Services.TokenJWT.dto; 

public class DtoOutputToken {
    public string token { get; set; }
}
﻿namespace Application.UseCases.Authentication.Dtos;

public class DtoOutputRegistration
{
    public bool IsInDb { get; set; }
}
﻿namespace Application.UseCases.Address.Dtos;

public class DtoOutputAddressId
{
    public int Id { get; set; }
}
using Domain.Entities.Users;

namespace Tests;

public class UserTests
{
    

    [Test]
    public void Test1()
    {
        
        Assert.Pass();
    }
}
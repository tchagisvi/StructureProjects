export interface DtoInputUsername {
  username: string
}

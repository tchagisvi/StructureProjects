export interface DtoOutputAdmin {
  id: number;
  username:string;
  userType: string;
  password:string;
  email: string;
  birthdate: Date;
  phoneNumber: string;
}

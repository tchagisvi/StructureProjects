export interface DtoOuputCar {
  numberPlate: string,
  brand: string,
  model: string,
  nbSeats: number,
  fuelType: number,
  carType: number,
  color: string
}

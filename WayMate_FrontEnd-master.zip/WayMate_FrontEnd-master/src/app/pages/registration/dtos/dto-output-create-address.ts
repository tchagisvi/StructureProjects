export interface DtoOutputCreateAddress {
  street:string;
  postalCode:string;
  city:string;
  number:string;
  country: string;
}

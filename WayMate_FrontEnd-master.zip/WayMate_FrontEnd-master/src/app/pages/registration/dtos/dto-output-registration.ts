export interface DtoOutputRegistration {
  isInDb: boolean;
}

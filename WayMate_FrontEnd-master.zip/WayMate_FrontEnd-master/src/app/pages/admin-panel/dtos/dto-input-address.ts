export interface DtoInputAddress {
  id: number;
  street: string;
  postalCode: string;
  city: string;
  number: string;
  country: string;
}

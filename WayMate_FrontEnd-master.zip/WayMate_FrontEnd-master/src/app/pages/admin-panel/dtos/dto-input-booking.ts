export interface DtoInputBooking {
  id: number;
  date: Date;
  reservedSeats: number;
  idPassenger: number;
  idTrip: number;
}

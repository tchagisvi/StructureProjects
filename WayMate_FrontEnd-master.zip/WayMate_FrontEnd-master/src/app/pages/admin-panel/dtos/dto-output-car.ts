export interface DtoOutputCar {
  numberPlate: string;
  model: string;
  nbSeats: number;
  brand: string;
  carType: string;
  fuelType: string;
  color: string;
}

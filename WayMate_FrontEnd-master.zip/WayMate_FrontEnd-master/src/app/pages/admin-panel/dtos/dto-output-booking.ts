export interface DtoOutputBooking {
  id: number;
  date: Date;
  reservedSeats: number;
  idPassenger: number;
  idTrip: number;
}

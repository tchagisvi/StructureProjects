export interface DtoOutputAdmin {
  id: number;
  username:string;
  password:string;
  email: string;
  birthdate: Date;
  isBanned: string;
  phoneNumber: string;
}

export interface DtoInputCar {
  numberPlate: string;
  model: string;
  nbSeats: number;
  brand: string;
  carType: string;
  fuelType: string;
  color: string;
}

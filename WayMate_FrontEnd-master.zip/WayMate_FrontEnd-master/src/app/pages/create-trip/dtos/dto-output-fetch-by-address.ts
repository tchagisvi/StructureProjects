export interface DtoOutputFetchByAddress {
  id:number;
}

export interface DtoInputAddress {
  id:number;
}

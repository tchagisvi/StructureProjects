export interface DtoOutputConnection {
  islogged: boolean,
  username: string,
  usertype: string
}

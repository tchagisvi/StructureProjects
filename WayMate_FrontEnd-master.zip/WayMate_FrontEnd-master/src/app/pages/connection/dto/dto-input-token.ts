export interface DtoInputToken {
  username: string,
  usertype: string
}

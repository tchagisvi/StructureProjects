export interface DtoOutputToken {
  token: string;
}

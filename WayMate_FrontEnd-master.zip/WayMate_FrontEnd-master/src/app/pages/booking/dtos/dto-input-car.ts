export interface DtoInputCar {
  id:number;
  numberPlate:string;
  brand:string;
  model:string;
  nbSeats:number;
  fuelType:string;
  carType:string;
  color: string;
}

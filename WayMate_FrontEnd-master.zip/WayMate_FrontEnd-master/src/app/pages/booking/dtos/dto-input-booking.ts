export interface DtoInputBooking {
  id: number;
  date: Date;
  reservedSeats: number;
  IdPassenger: number;
  IdTrip: number;
}

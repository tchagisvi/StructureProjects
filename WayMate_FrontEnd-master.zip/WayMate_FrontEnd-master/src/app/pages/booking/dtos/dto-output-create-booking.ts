export interface DtoOutputCreateBooking {
  date: Date;
  reservedSeats: number;
  IdPassenger: number;
  IdTrip: number;
}

export const environment = {
  BASE_URL_API: "https://localhost:7206/api/v1"
};

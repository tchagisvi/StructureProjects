﻿using Application.UseCases.Games.Dtos;
using Application.UseCases.History.Dtos;
using Application.UseCases.Users.Dtos;
using AutoMapper;
using Domain;
using Infrastructure.Ef.DbEntities;

namespace Application;

public class Mapper : Profile
{
    public Mapper()
    {
        // Source, Destination
        // User
        CreateMap<User, DtoOutputUser>();
        CreateMap<DbUser, DtoOutputUser>();
        CreateMap<DbUser, User>();
        // Game
        CreateMap<DtoInputCreateGame, Game>();
        CreateMap<Game, DtoOutputGame>();
        CreateMap<DbGame, Game>();
        CreateMap<DbGame, DtoOutputGame>();
        CreateMap<Game, DtoOutputHistory.Game>();
        CreateMap<DbGame, DtoOutputPlayingSession.DtoGame>();

        // History & entries
        CreateMap<DtoInputCreatePlayingSession, DbPlayingSession>();
        CreateMap<DbPlayingSession, DtoOutputPlayingSession>();
        CreateMap<PlayingSession, DtoOutputHistory.PlayingSession>();
    }
}
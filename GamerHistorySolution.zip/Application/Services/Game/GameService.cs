﻿using AutoMapper;
using Infrastructure.Ef;

namespace Application.Services.Game;

public class GameService : IGameService
{
    private readonly IGameRepository _gameRepository;
    private readonly IMapper _mapper;

    public GameService(IGameRepository gameRepository, IMapper mapper)
    {
        _gameRepository = gameRepository;
        _mapper = mapper;
    }

    public Domain.Game FetchById(int id)
    {
        var dbGame = _gameRepository.FetchById(id);
        return _mapper.Map<Domain.Game>(dbGame);
    }
}
﻿namespace Application.Services.Game;

public interface IGameService
{
    Domain.Game FetchById(int id);
}
﻿using Application.Services.Game;
using Domain;
using Infrastructure.Ef;

namespace Application.Services.History;

public class HistoryService : IHistoryService
{
    private readonly IPlayingSessionRepository _playingSessionRepository;
    private readonly IGameService _gameService;

    public HistoryService(IPlayingSessionRepository playingSessionRepository, IGameService gameService)
    {
        _playingSessionRepository = playingSessionRepository;
        _gameService = gameService;
    }

    public Domain.History Fetch(int userId)
    {
        var dbPlayingSessions = _playingSessionRepository.FilterByUserId(userId);
        var playingSessions = dbPlayingSessions.Select(dbPlayingSession => new PlayingSession
        {
            Id = dbPlayingSession.Id,
            Game = _gameService.FetchById(dbPlayingSession.GameId),
            MinutesPlayed = dbPlayingSession.MinutesPlayed
        });

        return Domain.History.Of(playingSessions);
    }
}
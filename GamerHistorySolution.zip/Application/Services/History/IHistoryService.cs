﻿namespace Application.Services.History;

public interface IHistoryService
{
    Domain.History Fetch(int userId);
}
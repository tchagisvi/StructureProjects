﻿using Application.UseCases.Games.Dtos;
using Application.UseCases.Utils;
using AutoMapper;
using Domain;
using Infrastructure.Ef;

namespace Application.UseCases.Games;

public class UseCaseCreateGame : IUseCaseWriter<DtoOutputGame, DtoInputCreateGame>
{
    private readonly IGameRepository _gameRepository;
    private readonly IMapper _mapper;

    public UseCaseCreateGame(IGameRepository gameRepository, IMapper mapper)
    {
        _gameRepository = gameRepository;
        _mapper = mapper;
    }

    public DtoOutputGame Execute(DtoInputCreateGame input)
    {
        // We create an instance of game for its internal checking
        // See MinutesForCompletion property
        var game = _mapper.Map<Game>(input);
        var dbGame = _gameRepository.Create(game.Name, game.MinutesForCompletion);
        return _mapper.Map<DtoOutputGame>(dbGame);
    }
}
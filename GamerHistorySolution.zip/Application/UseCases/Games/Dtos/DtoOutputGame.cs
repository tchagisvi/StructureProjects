﻿namespace Application.UseCases.Games.Dtos;

public class DtoOutputGame
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int MinutesForCompletion { get; set; }
}
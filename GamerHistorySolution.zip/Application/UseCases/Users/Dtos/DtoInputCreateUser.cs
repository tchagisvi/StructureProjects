﻿using System.ComponentModel.DataAnnotations;

namespace Application.UseCases.Users.Dtos;

public class DtoInputCreateUser
{
    [Required] public string FirstName { get; set; }
    [Required] public string LastName { get; set; }
}
﻿namespace Application.UseCases.Users.Dtos;

// Data
// Transfer
// Object
public class DtoOutputUser
{
    public int Id { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
}
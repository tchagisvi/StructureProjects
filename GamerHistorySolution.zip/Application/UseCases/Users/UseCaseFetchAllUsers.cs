﻿using Application.UseCases.Users.Dtos;
using Application.UseCases.Utils;
using AutoMapper;
using Infrastructure.Ef;

namespace Application.UseCases.Users;

public class UseCaseFetchAllUsers : IUseCaseQuery<IEnumerable<DtoOutputUser>>
{
    private readonly IUserRepository _userRepository;
    private readonly IMapper _mapper;

    public UseCaseFetchAllUsers(IUserRepository userRepository, IMapper mapper)
    {
        _userRepository = userRepository;
        _mapper = mapper;
    }

    public IEnumerable<DtoOutputUser> Execute()
    {
        var dbUsers = _userRepository.FetchAll();
        return _mapper.Map<IEnumerable<DtoOutputUser>>(dbUsers);
    }
}
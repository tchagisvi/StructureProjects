﻿using Application.UseCases.History.Dtos;
using Application.UseCases.Utils;
using AutoMapper;
using Domain;
using Infrastructure.Ef;
using Infrastructure.Ef.DbEntities;

namespace Application.UseCases.History;

public class UseCaseCreatePlayingSession : IUseCaseWriter<DtoOutputPlayingSession, DtoInputCreatePlayingSession>
{
    private readonly IPlayingSessionRepository _playingSessionRepository;
    private readonly IGameRepository _gameRepository;
    private readonly IMapper _mapper;

    public UseCaseCreatePlayingSession(IPlayingSessionRepository playingSessionRepository,
        IGameRepository gameRepository, IMapper mapper)
    {
        _playingSessionRepository = playingSessionRepository;
        _gameRepository = gameRepository;
        _mapper = mapper;
    }

    public DtoOutputPlayingSession Execute(DtoInputCreatePlayingSession input)
    {
        var playingSession = _mapper.Map<DbPlayingSession>(input);
        playingSession.UserId = input.UserId;
        _playingSessionRepository.Create(playingSession);

        var dbGame = _gameRepository.FetchById(playingSession.GameId);
        var dto = _mapper.Map<DtoOutputPlayingSession>(playingSession);
        dto.Game = _mapper.Map<DtoOutputPlayingSession.DtoGame>(dbGame);

        return dto;
    }
}
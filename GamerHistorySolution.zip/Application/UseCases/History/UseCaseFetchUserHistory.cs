﻿using Application.Services.History;
using Application.UseCases.History.Dtos;
using Application.UseCases.Utils;
using AutoMapper;
using Infrastructure.Ef;

namespace Application.UseCases.History;

public class UseCaseFetchUserHistory : IUseCaseParameterizedQuery<DtoOutputHistory, DtoInputFilteringHistory>
{
    private readonly IHistoryService _historyService;
    private readonly IPlayingSessionRepository _playingSessionRepository;
    private readonly IMapper _mapper;

    public UseCaseFetchUserHistory(IPlayingSessionRepository playingSessionRepository, IHistoryService historyService, IMapper mapper)
    {
        _playingSessionRepository = playingSessionRepository;
        _historyService = historyService;
        _mapper = mapper;
    }

    public DtoOutputHistory Execute(DtoInputFilteringHistory param)
    {
        var history = _historyService.Fetch(param.UserId);

        var playingSessions = (param.GameId.HasValue
            ? history.Where(pS => pS.Game.Id == param.GameId)
            : history).Entries();

        var dtos = _mapper.Map<IEnumerable<DtoOutputHistory.PlayingSession>>(playingSessions);
        return new DtoOutputHistory { TotalMinutesPlayed = history.TotalMinutesPlayed(), PlayingSessions = dtos };
    }
}
﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Application.UseCases.History.Dtos;

public class DtoInputCreatePlayingSession
{
    [JsonIgnore] public int UserId { get; set; }
    [Required] public int GameId { get; set; }

    [Required]
    [Range(1, int.MaxValue, ErrorMessage = "Only positive numbers are allowed")]
    public int MinutesPlayed { get; set; }
}
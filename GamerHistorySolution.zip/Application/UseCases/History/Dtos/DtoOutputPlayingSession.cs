﻿namespace Application.UseCases.History.Dtos;

public class DtoOutputPlayingSession
{
    public int Id { get; set; }
    public DtoGame Game { get; set; }
    public int MinutesPlayed { get; set; }

    public class DtoGame
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
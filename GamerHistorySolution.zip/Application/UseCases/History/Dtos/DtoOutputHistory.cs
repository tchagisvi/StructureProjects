﻿using Domain;

namespace Application.UseCases.History.Dtos;

public class DtoOutputHistory
{
    public int TotalMinutesPlayed { get; set; }
    public IEnumerable<PlayingSession> PlayingSessions { get; set; }

    public class PlayingSession
    {
        public int Id { get; set; }
        public Game Game { get; set; }
        public int MinutesPlayed { get; set; }
    }

    public class Game
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
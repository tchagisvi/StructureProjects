﻿namespace Application.UseCases.History.Dtos;

public class DtoInputFilteringHistory
{
    public int UserId { get; set; }
    public int? GameId { get; set; }
}
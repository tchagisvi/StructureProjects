﻿namespace Domain;

public class PlayingSession
{
    public int Id { get; set; }
    public Game Game { get; set; }
    public int MinutesPlayed { get; set; }
}
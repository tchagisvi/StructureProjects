﻿namespace Domain;

public class History
{
    private readonly List<PlayingSession> _entries = new();

    public static History Of(IEnumerable<PlayingSession> sessions)
    {
        var history = new History();
        history.AddRange(sessions);
        return history;
    }

    public void Add(PlayingSession playingSession)
    {
        _entries.Add(playingSession);
    }

    public void AddRange(IEnumerable<PlayingSession> sessions)
    {
        foreach (var playingSession in sessions)
            Add(playingSession);
    }

    public int TotalMinutesPlayed()
    {
        return _entries.Sum(e => e.MinutesPlayed);
    }

    public History Where(Predicate<PlayingSession> predicate)
    {
        return History.Of(_entries.Where(predicate.Invoke));
    }

    public IEnumerable<PlayingSession> Entries()
    {
        return _entries;
    }
}
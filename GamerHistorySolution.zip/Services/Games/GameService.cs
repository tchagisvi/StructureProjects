﻿using Infrastructure.Ef;
using Services.Games.Dtos;

namespace Services.Games;

public class GameService : IGameService
{
    private readonly IGameRepository _gameRepository;

    public GameService(IGameRepository gameRepository)
    {
        _gameRepository = gameRepository;
    }

    public IEnumerable<DtoOutputGame> FetchAll()
    {
        var games = _gameRepository.FetchAll();
        return Mapper.GetInstance().Map<IEnumerable<DtoOutputGame>>(games);
    }

    public DtoOutputGame Create(DtoInputCreateGame dto)
    {
        var game = _gameRepository.Create(dto.Name, dto.MinutesForCompletion);
        return Mapper.GetInstance().Map<DtoOutputGame>(game);
    }
}
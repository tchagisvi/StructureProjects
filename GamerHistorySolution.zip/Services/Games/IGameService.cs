﻿using Services.Games.Dtos;

namespace Services.Games;

public interface IGameService
{
    IEnumerable<DtoOutputGame> FetchAll();

    DtoOutputGame Create(DtoInputCreateGame dto);
}
﻿namespace Services.Games.Dtos;

public class DtoInputCreateGame
{
    public string Name { get; set; }
    public int MinutesForCompletion { get; set; }
}
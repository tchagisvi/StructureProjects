﻿using Infrastructure.Ef;
using Services.Users.Dtos;

namespace Services.Users;

public class UserService : IUserService
{
    private readonly IUserRepository _userRepository;

    public UserService(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public IEnumerable<DtoOutputUser> FetchAll()
    {
        var users = _userRepository.FetchAll();
        return Mapper.GetInstance().Map<IEnumerable<DtoOutputUser>>(users);
    }

    public DtoOutputUser FetchById(int id)
    {
        var user = _userRepository.FetchById(id);
        return Mapper.GetInstance().Map<DtoOutputUser>(user);
    }

    public DtoOutputUser Create(DtoInputCreateUser dto)
    {
        var user = _userRepository.Create(dto.FirstName, dto.LastName);
        return Mapper.GetInstance().Map<DtoOutputUser>(user);
    }
}
﻿using Services.Users.Dtos;

namespace Services.Users;

public interface IUserService
{
    IEnumerable<DtoOutputUser> FetchAll();
    DtoOutputUser FetchById(int id);
    DtoOutputUser Create(DtoInputCreateUser dto);
}
﻿namespace Services.Users.Dtos;

public class DtoInputCreateUser
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
}
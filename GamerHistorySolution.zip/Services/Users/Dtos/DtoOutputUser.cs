﻿namespace Services.Users.Dtos;

public class DtoOutputUser
{
    public int Id { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
}
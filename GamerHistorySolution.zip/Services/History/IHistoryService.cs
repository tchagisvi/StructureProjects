﻿using Services.History.Dtos;

namespace Services.History;

public interface IHistoryService
{
    DtoOutputPlayingSession CreateSession(int userId, DtoInputCreatePlayingSession dto);
    DtoOutputHistory FetchHistoryOf(int userId, DtoInputFilteringHistory dto);
}
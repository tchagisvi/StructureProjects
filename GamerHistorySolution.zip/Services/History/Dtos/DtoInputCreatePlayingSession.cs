﻿namespace Services.History.Dtos;

public class DtoInputCreatePlayingSession
{
    public int GameId { get; set; }
    public int MinutesPlayed { get; set; }
}
﻿namespace Services.History.Dtos;

public class DtoOutputHistory
{
    public IEnumerable<PlayingSession> PlayingSessions { get; set; }

    public class PlayingSession
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int GameId { get; set; }
        public int MinutesPlayed { get; set; }
    }
}
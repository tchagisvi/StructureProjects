﻿namespace Services.History.Dtos;

public class DtoInputFilteringHistory
{
    public int? GameId { get; set; }
}
﻿namespace Services.History.Dtos;

public class DtoOutputPlayingSession
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int GameId { get; set; }
    public int MinutesPlayed { get; set; }
}
﻿using Domain;
using Infrastructure.Ef;
using Services.History.Dtos;

namespace Services.History;

public class HistoryService : IHistoryService
{
    private readonly IPlayingSessionRepository _playingSessionRepository;

    public HistoryService(IPlayingSessionRepository playingSessionRepository)
    {
        _playingSessionRepository = playingSessionRepository;
    }

    public DtoOutputPlayingSession CreateSession(int userId, DtoInputCreatePlayingSession dto)
    {
        var mapper = Mapper.GetInstance();
        var playingSession = mapper.Map<PlayingSession>(dto);
        playingSession.UserId = userId;
        _playingSessionRepository.Create(playingSession);
        return mapper.Map<DtoOutputPlayingSession>(playingSession);
    }

    public DtoOutputHistory FetchHistoryOf(int userId, DtoInputFilteringHistory dto)
    {
        var playingSessions = _playingSessionRepository.FilterByUserId(userId);

        if (dto.GameId.HasValue)
            playingSessions = playingSessions.Where(p => p.GameId == dto.GameId);

        var dtos = Mapper.GetInstance().Map<IEnumerable<DtoOutputHistory.PlayingSession>>(playingSessions);
        return new DtoOutputHistory { PlayingSessions = dtos };
    }
}
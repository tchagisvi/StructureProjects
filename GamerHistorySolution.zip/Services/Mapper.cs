﻿using AutoMapper;
using Domain;
using Services.Games.Dtos;
using Services.History.Dtos;
using Services.Users.Dtos;

namespace Services;

public static class Mapper
{
    private static AutoMapper.Mapper _instance;

    public static AutoMapper.Mapper GetInstance()
    {
        return _instance ??= CreateMapper();
    }

    private static AutoMapper.Mapper CreateMapper()
    {
        var config = new MapperConfiguration(cfg =>
        {
            // Source, Destination
            cfg.CreateMap<User, DtoOutputUser>();
            cfg.CreateMap<Game, DtoOutputGame>();
            cfg.CreateMap<DtoInputCreatePlayingSession, PlayingSession>();
            cfg.CreateMap<PlayingSession, DtoOutputPlayingSession>();
            cfg.CreateMap<PlayingSession, DtoOutputHistory.PlayingSession>();
        });
        return new AutoMapper.Mapper(config);
    }
}
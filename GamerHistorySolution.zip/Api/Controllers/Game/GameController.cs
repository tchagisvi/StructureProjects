﻿using Application.UseCases.Games;
using Application.UseCases.Games.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers.Game;

[ApiController]
[Route("api/v1/games")]
public class GameController : ControllerBase
{
    private readonly UseCaseCreateGame _useCaseCreateGame;
    private readonly UseCaseFetchAllGames _useCaseFetchAllGames;

    public GameController(UseCaseCreateGame useCaseCreateGame, UseCaseFetchAllGames useCaseFetchAllGames)
    {
        _useCaseCreateGame = useCaseCreateGame;
        _useCaseFetchAllGames = useCaseFetchAllGames;
    }

    [HttpGet]
    public ActionResult<IEnumerable<DtoOutputGame>> FetchAll()
    {
        return Ok(_useCaseFetchAllGames.Execute());
    }

    [HttpPost]
    public ActionResult<DtoOutputGame> Create(DtoInputCreateGame dto)
    {
        return Ok(_useCaseCreateGame.Execute(dto));
    }
}
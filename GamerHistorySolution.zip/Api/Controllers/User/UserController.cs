﻿using Application.UseCases.History;
using Application.UseCases.History.Dtos;
using Application.UseCases.Users;
using Application.UseCases.Users.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers.User;

[ApiController]
[Route("api/v1/users")]
public class UserController : ControllerBase
{
    private readonly UseCaseCreatePlayingSession _useCaseCreatePlayingSession;
    private readonly UseCaseCreateUser _useCaseCreateUser;
    private readonly UseCaseFetchAllUsers _useCaseFetchAllUsers;
    private readonly UseCaseFetchUserById _useCaseFetchUserById;
    private readonly UseCaseFetchUserHistory _useCaseFetchUserHistory;
    
    public UserController(UseCaseCreateUser useCaseCreateUser, UseCaseFetchAllUsers useCaseFetchAllUsers,
        UseCaseFetchUserById useCaseFetchUserById, UseCaseFetchUserHistory useCaseFetchUserHistory,
        UseCaseCreatePlayingSession useCaseCreatePlayingSession)
    {
        _useCaseCreateUser = useCaseCreateUser;
        _useCaseFetchAllUsers = useCaseFetchAllUsers;
        _useCaseFetchUserById = useCaseFetchUserById;
        _useCaseFetchUserHistory = useCaseFetchUserHistory;
        _useCaseCreatePlayingSession = useCaseCreatePlayingSession;
    }

    [HttpGet]
    public ActionResult<IEnumerable<DtoOutputUser>> FetchAll()
    {
        return Ok(_useCaseFetchAllUsers.Execute());
    }

    [HttpGet]
    [Route("{id:int}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public ActionResult<DtoOutputUser> FetchById(int id)
    {
        try
        {
            return _useCaseFetchUserById.Execute(id);
        }
        catch (KeyNotFoundException e)
        {
            return NotFound(new
            {
                e.Message
            });
        }
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    public ActionResult<DtoOutputUser> Create(DtoInputCreateUser dto)
    {
        var output = _useCaseCreateUser.Execute(dto);
        return CreatedAtAction(
            nameof(FetchById),
            new { id = output.Id },
            output
        );
    }

    [HttpGet]
    [Route("{id:int}/history")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public ActionResult<DtoOutputHistory> FetchHistory(int id, [FromQuery] int? gameId)
    {
        try
        {
            return Ok(_useCaseFetchUserHistory.Execute(new DtoInputFilteringHistory
            {
                UserId = id,
                GameId = gameId
            }));
        }
        catch (KeyNotFoundException e)
        {
            return NotFound(new
            {
                e.Message
            });
        }
    }

    [HttpPost]
    [Route("{id:int}/history")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public ActionResult<DtoOutputPlayingSession> CreateHistoryEntry(int id, DtoInputCreatePlayingSession dto)
    {
        dto.UserId = id;
        return CreatedAtAction(nameof(FetchHistory), new { id }, _useCaseCreatePlayingSession.Execute(dto));
    }
}
﻿using Infrastructure.Ef.DbEntities;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Ef;

public class GameHistoryContext : DbContext
{
    public GameHistoryContext(DbContextOptions options) : base(options)
    {
    }
    public DbSet<DbUser> Users { get; set; }
    public DbSet<DbGame> Games { get; set; }
    public DbSet<DbPlayingSession> PlayingSessions { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DbUser>(entity =>
        {
            entity.ToTable("users");
            entity.HasKey(u => u.Id);
            entity.Property(u => u.Id).HasColumnName("id");
            entity.Property(u => u.FirstName).HasColumnName("first_name");
            entity.Property(u => u.LastName).HasColumnName("last_name");
        });

        modelBuilder.Entity<DbGame>(entity =>
        {
            entity.ToTable("games");
            entity.HasKey(g => g.Id).HasName("id");
            entity.Property(g => g.Name).HasColumnName("name");
            entity.Property(g => g.MinutesForCompletion).HasColumnName("minutes_for_completion");
        });

        modelBuilder.Entity<DbPlayingSession>(entity =>
        {
            entity.ToTable("history_items");
            entity.HasKey(h => h.Id).HasName("id");
            entity.Property(h => h.GameId).HasColumnName("game_id");
            entity.Property(h => h.UserId).HasColumnName("user_id");
            entity.Property(h => h.MinutesPlayed).HasColumnName("minutes_time_played");
        });
    }
}
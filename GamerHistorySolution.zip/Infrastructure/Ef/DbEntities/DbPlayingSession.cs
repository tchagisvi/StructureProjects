﻿namespace Infrastructure.Ef.DbEntities;

public class DbPlayingSession
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int GameId { get; set; }
    public int MinutesPlayed { get; set; }
}
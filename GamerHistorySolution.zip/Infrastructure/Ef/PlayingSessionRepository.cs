﻿using Infrastructure.Ef.DbEntities;

namespace Infrastructure.Ef;

public class PlayingSessionRepository : IPlayingSessionRepository
{
    private readonly GameHistoryContext _context;

    public PlayingSessionRepository(GameHistoryContext context)
    {
        _context = context;
    }

    public DbPlayingSession Create(DbPlayingSession playingSession)
    {
        _context.PlayingSessions.Add(playingSession);
        _context.SaveChanges();
        return playingSession;
    }

    public IEnumerable<DbPlayingSession> FilterByUserId(int userId)
    {
        var playingSessions = _context.PlayingSessions
            .Where(p => p.UserId == userId)
            .ToList();

        if (playingSessions.Count == 0)
            throw new KeyNotFoundException($"User with id {userId} has not been found");

        return playingSessions;
    }
}
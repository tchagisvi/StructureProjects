﻿using Infrastructure.Ef.DbEntities;

namespace Infrastructure.Ef;

public class GameRepository : IGameRepository
{
    private readonly GameHistoryContext _context;

    public GameRepository(GameHistoryContext context)
    {
        _context = context;
    }

    public IEnumerable<DbGame> FetchAll()
    {
        return _context.Games.ToList();
    }

    public DbGame FetchById(int id)
    {
        var game = _context.Games.FirstOrDefault(g => g.Id == id);
        
        if (game == null)
            throw new KeyNotFoundException($"Game with id {id} has not been found");

        return game;
    }

    public DbGame Create(string name, int minutesForCompletion)
    {
        var game = new DbGame
        {
            Name = name,
            MinutesForCompletion = minutesForCompletion
        };
        _context.Games.Add(game);
        _context.SaveChanges();
        return game;
    }
}
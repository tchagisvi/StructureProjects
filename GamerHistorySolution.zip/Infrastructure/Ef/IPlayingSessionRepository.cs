﻿using Domain;
using Infrastructure.Ef.DbEntities;

namespace Infrastructure.Ef;

public interface IPlayingSessionRepository
{
    DbPlayingSession Create(DbPlayingSession playingSession);
    IEnumerable<DbPlayingSession> FilterByUserId(int userId);
}
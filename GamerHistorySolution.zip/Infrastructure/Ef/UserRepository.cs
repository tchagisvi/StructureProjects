﻿using Infrastructure.Ef.DbEntities;

namespace Infrastructure.Ef;

public class UserRepository : IUserRepository
{
    private readonly GameHistoryContext _context;

    public UserRepository(GameHistoryContext context)
    {
        _context = context;
    }

    public IEnumerable<DbUser> FetchAll()
    {
        return _context.Users.ToList();
    }

    public DbUser FetchById(int id)
    {
        var user = _context.Users.FirstOrDefault(u => u.Id == id);

        if (user == null) throw new KeyNotFoundException($"User with id {id} has not been found");

        return user;
    }

    public DbUser Create(string firstName, string lastName)
    {
        var user = new DbUser { FirstName = firstName, LastName = lastName };
        _context.Users.Add(user);
        _context.SaveChanges();
        return user;
    }
}
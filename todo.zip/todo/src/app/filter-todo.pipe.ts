import {Pipe, PipeTransform} from '@angular/core';
import {TodoList} from "./todo";
import {TypeFilterTodo} from "./type-filter-todo.enum";

@Pipe({
  name: 'filterTodo'
})
export class FilterTodoPipe implements PipeTransform {

  transform(todoList: TodoList, typeFilter: TypeFilterTodo = TypeFilterTodo.ALL): TodoList {
    switch (typeFilter) {
      case TypeFilterTodo.DONE: return todoList.filter(todo => todo.isDone);
      case TypeFilterTodo.PENDING: return todoList.filter(todo => !todo.isDone);
      default: return todoList;
    }
  }

}

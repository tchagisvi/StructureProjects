import {Component, HostListener, OnDestroy, OnInit} from '@angular/core';
import {LocalTodoService} from "./local-todo.service";
import {Todo} from "./todo";
import {TodoCreatedService} from "./todo-created.service";
import {Subscription} from "rxjs";
import {subscribeToIterable} from "rxjs/internal-compatibility";
import {MOCK_TODO} from "./mock-todo";
import {ElementToDelete} from "./element-to-delete";
import {TodoService} from "./todo.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy
{
  // title = 'todo';

  private todos: Todo[] = [];
  private subscriptions: Subscription [] = [];

  constructor(public todoService: TodoService, public todoCreatedService: TodoCreatedService) {

  }

  ngOnInit(): void {
    this.loadTodos();
    this.listenToNewTodoCreated();
  }

  ngOnDestroy(): void {
    for (const sub of this.subscriptions) {
      sub.unsubscribe();
    }
  }

  private loadTodos() : void {
    this.todoService.query().subscribe(todos => this.todos = todos);
  }

  private listenToNewTodoCreated(): void {
    this.subscriptions.push(this.todoCreatedService.$todoCreated.subscribe(newTodo => this.createTodo(newTodo)));
  }

  @HostListener("dblclick")
  initWithMockTodos() {
    MOCK_TODO.forEach(todo => this.todos.push(todo));
  }

  createTodo(todo: Todo) {
    const sub = this.todoService.post(todo).subscribe(todoFromDb => this.todos.push(todoFromDb));
    this.subscriptions.push(sub);
  }

  deleteTodo($event: ElementToDelete<Todo>) {
    this.todos.splice($event.index, 1);
  }

  putTodo($event: Todo) {
    const sub = this.todoService.put($event).subscribe();
  }
}

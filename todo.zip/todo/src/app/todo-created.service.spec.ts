import { TestBed } from '@angular/core/testing';

import { TodoCreatedService } from './todo-created.service';

describe('TodoCreatedService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TodoCreatedService = TestBed.get(TodoCreatedService);
    expect(service).toBeTruthy();
  });
});

import {Todo} from "./todo";

export const MOCK_TODO:Todo[] = [
  {
    id: 1,
    title:"Study TI",
    isDone: false
  },
  {
    id: 2,
    title:"Love TI",
    isDone: true
  },
  {
    id: 3,
    title:"Training with Angular",
    isDone: true
  }
];

export interface ElementToDelete<T> {
  object: T;
  index: number;
}

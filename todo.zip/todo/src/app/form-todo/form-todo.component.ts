import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Todo} from "../todo";
import {TodoCreatedService} from "../todo-created.service";

@Component({
  selector: 'app-form-todo',
  templateUrl: './form-todo.component.html',
  styleUrls: ['./form-todo.component.css']
})
export class FormTodoComponent implements OnInit {
  form: FormGroup = this.fb.group({
    title: this.fb.control('', Validators.required)
  });

  constructor(public fb: FormBuilder, public todoCreatedService: TodoCreatedService) {

  }

  ngOnInit() {
  }

  buildTodo(): Todo {
    return {
      title: this.form.get("title").value,
      isDone: false
    }
  }

  notifyNewTodo() {
    this.todoCreatedService.notify(this.buildTodo());
    this.form.reset();
  }
}

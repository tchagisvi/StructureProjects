export enum TypeFilterTodo {
  ALL,
  DONE,
  PENDING
}

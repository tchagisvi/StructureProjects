import { Injectable } from '@angular/core';
import {Observable, of} from "rxjs";
import {Todo, TodoList} from "./todo";
import {MOCK_TODO} from "./mock-todo";

@Injectable({
  providedIn: 'root'
})
export class LocalTodoService {

  public static readonly KEY_TODOS:string = 'todos';

  constructor() { }

  query(): Observable<TodoList> {
    // Si le premier élément est faux (null), on stock un tableau dans la variable
    const todos: TodoList = JSON.parse(localStorage.getItem(LocalTodoService.KEY_TODOS)) || [];
    return of(todos);
  }

  postAll(todoList: TodoList) {
    localStorage.setItem(LocalTodoService.KEY_TODOS, JSON.stringify(todoList));
  }
}

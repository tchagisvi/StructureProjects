import { Injectable } from '@angular/core';
import {Todo} from "./todo";
import {Observable, Subject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class TodoCreatedService {
  private subject:Subject<Todo> = new Subject<Todo>();
  public $todoCreated:Observable<Todo> = this.subject.asObservable();

  constructor() { }

  notify(todo: Todo): void {
    this.subject.next(todo);
  }
}

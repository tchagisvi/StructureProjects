import { FilterTodoPipe } from './filter-todo.pipe';

describe('FilterTodoPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTodoPipe();
    expect(pipe).toBeTruthy();
  });
});

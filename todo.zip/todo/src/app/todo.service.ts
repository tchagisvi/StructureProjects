import { Injectable } from '@angular/core';
import {Todo, TodoList} from "./todo";
import {Observable} from "rxjs";
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  private static URL: string = "/api/todo";

  constructor(public http:HttpClient) { }

  query(): Observable<TodoList> {
    return this.http.get<TodoList>(TodoService.URL);
  }

  post(todo: Todo): Observable<Todo> {
    return this.http.post<Todo>(TodoService.URL, todo);
  }

  put(todo: Todo): Observable<any> {
    return this.http.put(TodoService.URL, todo);
  }

  delete(todo: Todo): Observable<any> {
    return this.http.delete(TodoService.URL);
  }
}

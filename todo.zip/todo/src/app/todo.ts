export declare type TodoList = Todo[];

export interface Todo {
  // le ? permet de rendre le champ facultatif
  id?: number,
  title: string,
  isDone: boolean;
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListTodoComponent } from './list-todo/list-todo.component';
import { FormTodoComponent } from './form-todo/form-todo.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { FilterTodoPipe } from './filter-todo.pipe';
import {HttpClientModule} from "@angular/common/http";

@NgModule({
  declarations: [
    AppComponent,
    ListTodoComponent,
    FormTodoComponent,
    FilterTodoPipe,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,

    // Module HTTP à ajouter
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

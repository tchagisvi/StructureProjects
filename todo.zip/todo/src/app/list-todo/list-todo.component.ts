import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {Todo, TodoList} from "../todo";
import {ElementToDelete} from "../element-to-delete";
import {TypeFilterTodo} from "../type-filter-todo.enum";
import {FilterTodoPipe} from "../filter-todo.pipe";

@Component({
  selector: 'app-list-todo',
  templateUrl: './list-todo.component.html',
  styleUrls: ['./list-todo.component.css']
})
export class ListTodoComponent implements OnInit, OnChanges {

  private _todos: Todo[];
  private _filteredTodos: TodoList;

  @Output()
  todoChange: EventEmitter<Todo> = new EventEmitter<Todo>();

  @Output()
  todoDelete: EventEmitter<ElementToDelete<Todo>> = new EventEmitter<ElementToDelete<Todo>>();
  private _filterSelected: TypeFilterTodo = TypeFilterTodo.ALL;

  readonly FILTERS : any[] = [{
    id: "all",
    value: TypeFilterTodo.ALL
  },
  {
    id: "done",
    value: TypeFilterTodo.DONE
  },
  {
    id: "pending",
    value: TypeFilterTodo.PENDING
  }];

  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges): void {
    this._filteredTodos = this._todos;
    this.updateFilteredTodoList();
  }

  emitTodoChange(todo:Todo) {
    this.updateFilteredTodoList();
    this.todoChange.next(todo);
  }

  emitTodoDelete(todo:Todo, index: number) {
    this.todoDelete.next( {
      object: todo,
      index: index
    });
  }

  private updateFilteredTodoList()
  {
    this._filteredTodos = new FilterTodoPipe().transform(this._todos, this._filterSelected);
  }

  get todos(): Todo[] {
    return this._todos;
  }

  @Input()
  set todos(value: Todo[]) {
    this._todos = value;
  }

  get filterSelected(): TypeFilterTodo {
    return this._filterSelected;
  }

  set filterSelected(value: TypeFilterTodo) {
    this._filterSelected = value;
  }

  get filteredTodos(): Todo[] {
    return this._filteredTodos;
  }

  set filteredTodos(value: Todo[]) {
    this._filteredTodos = value;
  }

  areAllElementsAreDisplayed() {
    return this.filterSelected === TypeFilterTodo.ALL;
  }
}
